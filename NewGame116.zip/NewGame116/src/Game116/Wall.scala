package Game116

class Wall(var endP1: Location, var endP2: Location) {

}
