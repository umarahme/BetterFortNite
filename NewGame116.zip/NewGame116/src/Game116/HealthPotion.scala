package Game116

class HealthPotion(loc: Location) extends Items(loc){
  var potion: Double = 20.0
  var Loc: Location = loc
}
