package Game116

class Weapons(loc: Location) extends Items(loc) {
  var damage: Double = 10.0
  var Loc: Location = loc
}

