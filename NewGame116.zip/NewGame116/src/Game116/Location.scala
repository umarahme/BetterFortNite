package Game116

class Location(var x:Double, var y:Double) {

}
