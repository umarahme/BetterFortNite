package Game116

abstract class Items(loc: Location) {

}
