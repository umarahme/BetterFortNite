package Game116

class World() {
  var players: List[Player] = List()
  var potions: List[HealthPotion] = List()
  var walls: List[Wall] = List()
}
