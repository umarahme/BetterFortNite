import unittest
import Game

class MyTestCase(unittest.TestCase):
    def test_something(self):
        nLoc = Game.Location(5,4)
        loc2 = Game.Location(5,6)
        loc3 = Game.Location(4,8)
        loc4 = Game.Location(3,7)
        wp = Game.Weapons(loc3)
        player1 = Game.Player("DeVante",nLoc)
        player2 = Game.Player("Patryk",loc2)
        player1.attack(player2)
        player2.attack(player1)
        player2.attack(player1)
        #attack works when players are close
        self.assertEqual(player1.health, 94.0)
        self.assertEqual(player2.health, 97.0)
        player1.loc = Game.Location(2,7)
        #player health does not change bc not close enough
        player1.attack(player2)
        self.assertEqual(player2.health,97.0)
        player1.health = 15.0
        #attacks with a weapon this time
        Game.cause_damage(player1,wp)
        #cause damage works in normal case
        self.assertEqual(player1.health,5.0)
        Game.cause_damage(player1,wp)
        #health cant go below 0
        self.assertEqual(player1.health, 0.0)



if __name__ == '__main__':
    unittest.main()
