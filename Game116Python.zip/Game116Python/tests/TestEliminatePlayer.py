import unittest
import Game

class MyTestCase(unittest.TestCase):
    def test_something(self):
        loc1 = Game.Location(4,3)
        loc2 = Game.Location(5,6)
        loc3 = Game.Location(4,8)
        loc4 = Game.Location(3,7)
        loc5 = Game.Location(1,4)
        loc6 = Game.Location(6,3)
        player1 = Game.Player("DeVante",loc1)
        player2 = Game.Player("Patryk",loc1)
        player3 = Game.Player("Umar",loc1)
        player4 = Game.Player("Bob",loc1)
        player5 = Game.Player("Jesse",loc1)
        player6 = Game.Player("Carl",loc1)
        newList = [player1,player2,player3,player4,player5,player6]
        newWorld = Game.World
        newWorld.players = newList
        player1.health = 0
        Game.eliminate_player(newWorld)
        #eliminates player from beginning
        self.assertEqual(newWorld.players, [player2,player3,player4,player5,player6])
        player6.health = 0
        player3.health = 0
        Game.eliminate_player(newWorld)
        #eliminates player from middle and end
        self.assertEqual(newWorld.players, [player2,player4,player5])
        Game.eliminate_player(newWorld)
        #no players have 0 health
        self.assertEqual(newWorld.players, [player2,player4,player5])
        player2.health = 0
        player4.health = 0
        Game.eliminate_player(newWorld)
        self.assertEqual(newWorld.players, [player5])
        player5.health = 0
        Game.eliminate_player(newWorld)
        #if 1 player is left and has 0 health
        self.assertEqual(newWorld.players,[])
        #method does not go through if no players are alive
        Game.eliminate_player(newWorld)
        self.assertEqual(newWorld.players, [])

if __name__ == '__main__':
    unittest.main()
