import unittest
import Game

class MyTestCase(unittest.TestCase):
    def test_something(self):
        nLoc = Game.Location(5,4)
        loc2 = Game.Location(5,6)
        loc3 = Game.Location(4,8)
        wp = Game.Weapons(loc3)
        player1 = Game.Player("DeVante",nLoc)
        player2 = Game.Player("Patryk",loc2)
        newPotion = Game.HealthPotion(loc2)
        Game.add_potion(player1,newPotion)
        #player health is already full
        self.assertEqual(player1.health, 100)
        #basic addition to health with potion
        player1.attack(player2)
        player1.attack(player2)
        player1.attack(player2)
        Game.cause_damage(player2,wp)
        Game.cause_damage(player2,wp)
        Game.add_potion(player2,newPotion)
        self.assertEqual(player2.health, 91.0)
        #health should not go over 100
        Game.add_potion(player2,newPotion)
        self.assertEqual(player2.health,100.0)
        #health goes down to 0
        for i in range(10):
            Game.cause_damage(player2,wp)
        self.assertEqual(player2.health,0.0)
        #health should not go below 0
        Game.cause_damage(player2,wp)
        self.assertEqual(player2.health, 0.0)
        #health should not add if player is not at same location of potion
        hp2 = Game.HealthPotion(loc3)
        Game.add_potion(player2,hp2)
        self.assertEqual(player2.health,0.0)





if __name__ == '__main__':
    unittest.main()
