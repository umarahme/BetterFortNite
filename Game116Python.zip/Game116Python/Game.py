import math
class Player:
    health = 100
    attackAmt = 3.0
    weaponsOwned = 0.0
    def __init__(self, name, loc):
        self.name = name
        self.loc = loc
    def attack(self,p2):
        if(abs(p2.loc.x-self.loc.x) <=2 and abs(p2.loc.y-self.loc.y)<=2):
            p2.health = p2.health - self.attackAmt
class Location:
    def __init__(self,x,y):
        self.x = x
        self.y = y

class HealthPotion:
    potion = 20.0
    def __init__(self,loc):
        self.loc = loc

class Weapons:
    damage = 10.0
    def __init__(self,loc):
        self.loc = loc

class Wall:
    def __init__(self, endP1, endP2):
        self.endP1 = endP1
        self.endP2 = endP2

class World:
    players = []
    potions = []
    walls = []


#class Game:
def add_potion(p,health):
    if(p.loc == health.loc):
        if(p.health == 100):
            p.health =100
        elif(p.health + health.potion >=100):
            p.health = 100
        else:
            p.health = p.health + health.potion


def cause_damage(p,wp):
    if(p.health - wp.damage <= 0):
        p.health = 0
    else:
        p.health = p.health - wp.damage

def eliminate_player(w):
    i = 0
    first = []
    end = []
    temp = []
    if(len(w.players)>0):
        for p in w.players:
            if(p.health==0):
                i = w.players.index(p)
                if(i==0):
                    first = w.players[1:len(w.players)]
                    w.players = first
                elif(i==len(w.players)-1):
                    first = w.players[0:len(w.players)-1]
                    w.players = first
                else:
                    first = w.players[0:i]
                    end = w.players[i+1:len(w.players)]
                    w.players = first + end

